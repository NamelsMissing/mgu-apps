#ifndef LIBRETRO_CORE_OPTIONS_H__
#define LIBRETRO_CORE_OPTIONS_H__

#include <stdlib.h>
#include <string.h>

#include <libretro.h>
#include <retro_inline.h>

#ifndef HAVE_NO_LANGEXTRA
#include "libretro_core_options_intl.h"
#endif

/*
 ********************************
 * VERSION: 1.3
 ********************************
 *
 * - 1.3: Move translations to libretro_core_options_intl.h
 *        - libretro_core_options_intl.h includes BOM and utf-8
 *          fix for MSVC 2010-2013
 *        - Added HAVE_NO_LANGEXTRA flag to disable translations
 *          on platforms/compilers without BOM support
 * - 1.2: Use core options v1 interface when
 *        RETRO_ENVIRONMENT_GET_CORE_OPTIONS_VERSION is >= 1
 *        (previously required RETRO_ENVIRONMENT_GET_CORE_OPTIONS_VERSION == 1)
 * - 1.1: Support generation of core options v0 retro_core_option_value
 *        arrays containing options with a single value
 * - 1.0: First commit
*/

#ifdef __cplusplus
extern "C" {
#endif

/*
 ********************************
 * Core Option Definitions
 ********************************
*/

/* RETRO_LANGUAGE_ENGLISH */

/* Default language:
 * - All other languages must include the same keys and values
 * - Will be used as a fallback in the event that frontend language
 *   is not available
 * - Will be used as a fallback for any missing entries in
 *   frontend language definition */

struct retro_core_option_definition option_defs_us[] = {
   {
      "vb_3dmode",
      "3D mode (requires restart)",
      "Select the 3D mode. Anaglyph - used in conjunction with classic dual-lens-color glasses. Cyberscope - intended for use with the CyberScope 3D device. sidebyside - the left-eye image is displayed on the left, and the right-eye image is displayed on the right. vli - Vertical lines alternate between left and right view. hli - Horizontal lines alternate between left and right view. Does not apply to VR mode.",
      {
         { "anaglyph",  NULL },
         { "cyberscope",  NULL },
         { "side-by-side",  NULL },
         { "vli", NULL},
         { "hli", NULL},
         { NULL, NULL },
      },
      "anaglyph",
   },
   {
      "vb_anaglyph_preset",
      "Anaglyph preset",
      "Anaglyph preset colors.",
      {
         { "disabled",     NULL },
         { "red & blue",     NULL },
         { "red & cyan",     NULL },
         { "red & electric cyan",     NULL },
         { "green & magenta",     NULL },
         { "yellow & blue",     NULL },
         { NULL, NULL},
      },
      "disabled",
   },
   {
      "vb_sidebyside_separation",
      "Side-by-side separation",
      "Number of pixels to separate left and right views in side-by-side 3D mode.",
      {
         { "0",      NULL },
         { "4",      NULL },
         { "8",      NULL },
         { "12",     NULL },
         { "16",     NULL },
         { "20",     NULL },
         { "24",     NULL },
         { "28",     NULL },
         { "32",     NULL },
         { "36",     NULL },
         { "40",     NULL },
         { "44",     NULL },
         { "48",     NULL },
         { "52",     NULL },
         { "56",     NULL },
         { "60",     NULL },
         { "64",     NULL },
         { "68",     NULL },
         { "72",     NULL },
         { "76",     NULL },
         { "80",     NULL },
         { "84",     NULL },
         { "88",     NULL },
         { "92",     NULL },
         { "96",     NULL },
         { "100",    NULL },
         { "104",    NULL },
         { "108",    NULL },
         { "112",    NULL },
         { "116",    NULL },
         { "120",    NULL },
         { "124",    NULL },
         { "128",    NULL },
         { "132",    NULL },
         { "136",    NULL },
         { "140",    NULL },
         { "144",    NULL },
         { "148",    NULL },
         { "152",    NULL },
         { "156",    NULL },
         { "160",    NULL },
         { "164",    NULL },
         { "168",    NULL },
         { "172",    NULL },
         { "176",    NULL },
         { "180",    NULL },
         { "184",    NULL },
         { "188",    NULL },
         { "192",    NULL },
         { "196",    NULL },
         { "200",    NULL },
         { "204",    NULL },
         { "208",    NULL },
         { "212",    NULL },
         { "216",    NULL },
         { "220",    NULL },
         { "224",    NULL },
         { "228",    NULL },
         { "232",    NULL },
         { "236",    NULL },
         { "240",    NULL },
         { "244",    NULL },
         { "248",    NULL },
         { "252",    NULL },
         { "256",    NULL },
         { NULL, NULL},
      },
      "0",
   },
   {
      "vb_color_mode",
      "Palette",
      "",
      {
         { "black & red", NULL },
         { "black & white",  NULL },
         { "black & blue",  NULL },
         { "black & cyan",  NULL },
         { "black & electric cyan",  NULL },
         { "black & green",  NULL },
         { "black & magenta",  NULL },
         { "black & yellow",  NULL },
         { NULL, NULL},
      },
      "black & red",
   },
   {
      "vb_right_analog_to_digital",
      "Right analog to digital",
      "",
      {
         { "disabled",  NULL },
         { "enabled",  NULL },
         { "invert x",  NULL },
         { "invert y",  NULL },
         { "invert both",  NULL },
         { NULL, NULL },
      },
      "disabled",
   },
   {
      "vb_opposite_directions",
      "Allow Opposite Directions",
      "Allow pressing up and down or left and right directions at the same time. This may cause glitches.",
      {
         { "disabled", NULL },
         { "enabled", NULL },
         { NULL, NULL },
      },
      "disabled",
   },
   {
      "vb_cpu_emulation",
      "CPU emulation  (Restart)",
      "Choose between faster and accurate (slower) emulation.",
      {
         { "accurate",      NULL },
         { "fast",      NULL },
         { NULL, NULL},
      },
      "fast",
   },
   {
      "vb_vr",
      "VR",
      "Enabled shows both eyes as a stereo screen whenever the frontend presents them, in a headset or a stereo display mode. Disabled keeps the chosen 3D mode."
#if VB_VR_ENABLED
      " Head-locked holds the screen in front of the eyes in a headset (requires restart)."
#endif
      ,
      {
         { "disabled", NULL },
         { "enabled",  NULL },
#if VB_VR_ENABLED
         { "head-locked", NULL },
#endif
         { NULL,       NULL },
      },
      "enabled",
   },
#if VB_VR_ENABLED
   {
      "vb_vr_screen_distance",
      "VR screen distance",
      "Head-locked VR only. Apparent distance of the Virtual Boy screen from the viewer in metres. Closer values also pull the stereo image in.",
      {
         { "0.5", NULL },
         { "0.75", NULL },
         { "1.0", NULL },
         { "1.25", NULL },
         { "1.5", NULL },
         { "2.0", NULL },
         { "2.5", NULL },
         { "3.0", NULL },
         { NULL, NULL },
      },
      "1.0",
   },
   {
      "vb_vr_screen_width",
      "VR screen width",
      "Head-locked VR only. Width of the Virtual Boy screen in metres, at the chosen distance. Larger values fill more of your view, up to the edge of the headset's field of view.",
      {
         { "0.5", NULL },
         { "0.75", NULL },
         { "1.0", NULL },
         { "1.1", NULL },
         { "1.5", NULL },
         { "2.0", NULL },
         { "2.5", NULL },
         { "3.0", NULL },
         { NULL, NULL },
      },
      "1.1",
   },
#endif
   { NULL, NULL, NULL, { NULL, NULL }, NULL },
};

/*
 ********************************
 * Language Mapping
 ********************************
*/

#ifndef HAVE_NO_LANGEXTRA
struct retro_core_option_definition *option_defs_intl[RETRO_LANGUAGE_LAST] = {
   option_defs_us, /* RETRO_LANGUAGE_ENGLISH */
   NULL,           /* RETRO_LANGUAGE_JAPANESE */
   NULL,           /* RETRO_LANGUAGE_FRENCH */
   NULL,           /* RETRO_LANGUAGE_SPANISH */
   NULL,           /* RETRO_LANGUAGE_GERMAN */
   NULL,           /* RETRO_LANGUAGE_ITALIAN */
   NULL,           /* RETRO_LANGUAGE_DUTCH */
   NULL,           /* RETRO_LANGUAGE_PORTUGUESE_BRAZIL */
   NULL,           /* RETRO_LANGUAGE_PORTUGUESE_PORTUGAL */
   NULL,           /* RETRO_LANGUAGE_RUSSIAN */
   NULL,           /* RETRO_LANGUAGE_KOREAN */
   NULL,           /* RETRO_LANGUAGE_CHINESE_TRADITIONAL */
   NULL,           /* RETRO_LANGUAGE_CHINESE_SIMPLIFIED */
   NULL,           /* RETRO_LANGUAGE_ESPERANTO */
   NULL,           /* RETRO_LANGUAGE_POLISH */
   NULL,           /* RETRO_LANGUAGE_VIETNAMESE */
   NULL,           /* RETRO_LANGUAGE_ARABIC */
   NULL,           /* RETRO_LANGUAGE_GREEK */
   option_defs_tr, /* RETRO_LANGUAGE_TURKISH */
};
#endif

/*
 ********************************
 * Functions
 ********************************
*/

/* Handles configuration/setting of core options.
 * Should be called as early as possible - ideally inside
 * retro_set_environment(), and no later than retro_load_game()
 * > We place the function body in the header to avoid the
 *   necessity of adding more .c files (i.e. want this to
 *   be as painless as possible for core devs)
 */

static INLINE void libretro_set_core_options(retro_environment_t environ_cb)
{
   unsigned version = 0;

   if (!environ_cb)
      return;

   if (environ_cb(RETRO_ENVIRONMENT_GET_CORE_OPTIONS_VERSION, &version) && (version >= 1))
   {
#ifndef HAVE_NO_LANGEXTRA
      struct retro_core_options_intl core_options_intl;
      unsigned language = 0;

      core_options_intl.us    = option_defs_us;
      core_options_intl.local = NULL;

      if (environ_cb(RETRO_ENVIRONMENT_GET_LANGUAGE, &language) &&
          (language < RETRO_LANGUAGE_LAST) && (language != RETRO_LANGUAGE_ENGLISH))
         core_options_intl.local = option_defs_intl[language];

      environ_cb(RETRO_ENVIRONMENT_SET_CORE_OPTIONS_INTL, &core_options_intl);
#else
      environ_cb(RETRO_ENVIRONMENT_SET_CORE_OPTIONS, &option_defs_us);
#endif
   }
   else
   {
      size_t i;
      size_t num_options               = 0;
      struct retro_variable *variables = NULL;
      char **values_buf                = NULL;

      /* Determine number of options */
      while (true)
      {
         if (option_defs_us[num_options].key)
            num_options++;
         else
            break;
      }

      /* Allocate arrays */
      variables  = (struct retro_variable *)calloc(num_options + 1, sizeof(struct retro_variable));
      values_buf = (char **)calloc(num_options, sizeof(char *));

      if (!variables || !values_buf)
         goto error;

      /* Copy parameters from option_defs_us array */
      for (i = 0; i < num_options; i++)
      {
         const char *key                        = option_defs_us[i].key;
         const char *desc                       = option_defs_us[i].desc;
         const char *default_value              = option_defs_us[i].default_value;
         struct retro_core_option_value *values = option_defs_us[i].values;
         size_t buf_len                         = 3;
         size_t default_index                   = 0;

         values_buf[i] = NULL;

         if (desc)
         {
            size_t num_values = 0;

            /* Determine number of values */
            while (true)
            {
               if (values[num_values].value)
               {
                  /* Check if this is the default value */
                  if (default_value)
                     if (strcmp(values[num_values].value, default_value) == 0)
                        default_index = num_values;

                  buf_len += strlen(values[num_values].value);
                  num_values++;
               }
               else
                  break;
            }

            /* Build values string */
            if (num_values > 0)
            {
               size_t j;

               buf_len += num_values - 1;
               buf_len += strlen(desc);

               values_buf[i] = (char *)calloc(buf_len, sizeof(char));
               if (!values_buf[i])
                  goto error;

               strcpy(values_buf[i], desc);
               strcat(values_buf[i], "; ");

               /* Default value goes first */
               strcat(values_buf[i], values[default_index].value);

               /* Add remaining values */
               for (j = 0; j < num_values; j++)
               {
                  if (j != default_index)
                  {
                     strcat(values_buf[i], "|");
                     strcat(values_buf[i], values[j].value);
                  }
               }
            }
         }

         variables[i].key   = key;
         variables[i].value = values_buf[i];
      }

      /* Set variables */
      environ_cb(RETRO_ENVIRONMENT_SET_VARIABLES, variables);

error:

      /* Clean up */
      if (values_buf)
      {
         for (i = 0; i < num_options; i++)
         {
            if (values_buf[i])
            {
               free(values_buf[i]);
               values_buf[i] = NULL;
            }
         }

         free(values_buf);
         values_buf = NULL;
      }

      if (variables)
      {
         free(variables);
         variables = NULL;
      }
   }
}

#ifdef __cplusplus
}
#endif

#endif
