/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2007-2010 CaH4e3
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * VR02/VT03 Console and OneBus System
 *
 * Street Dance (Dance pad) (Unl)
 * 101-in-1 Arcade Action II
 * DreamGEAR 75-in-1, etc.
 *
 */

#include "mapinc.h"

static uint8_t submapper;
static void (*Sync)(void);
static uint8_t *CHRRAM;
static uint32_t CHRRAMSIZE;

/* General Purpose Registers */
static uint8_t cpu410x[64], ppu201x[16], apu40xx[64], reg4242, dipswitch;
static const uint8_t *cpuMangle, *ppuMangle, *mmc3Mangle;

/* IRQ Registers */
static uint8_t IRQCount, IRQa, IRQReload;
#define IRQLatch cpu410x[0x1]	/* accc cccc, a = 0, AD12 switching, a = 1, HSYNC switching */

/* MMC3 Registers */
#define mmc3cmd  cpu410x[0x5]	/* pcv- ----, p - program swap, c - video swap, v - internal VRAM enable */
#define mirror   cpu410x[0x6]	/* ---- ---m, m = 0 - H, m = 1 - V */

/* APU Registers */
static uint8_t pcm_enable = 0, pcm_irq = 0;
static int16_t pcm_addr, pcm_size, pcm_latch, pcm_clock = 0xE1;

static writefunc defapuwrite[64];
static readfunc defapuread[64];

static SFORMAT StateRegs[] =
{
	{ cpu410x, 64, "REGC" },
	{ ppu201x, 16, "REGS" },
	{ apu40xx, 64, "REGA" },
	{ &IRQReload, 1, "IRQR" },
	{ &IRQCount, 1, "IRQC" },
	{ &IRQa, 1, "IRQA" },
	{ &pcm_enable, 1, "PCME" },
	{ &pcm_irq, 1, "PCMI" },
	{ &pcm_addr, 2 | FCEUSTATE_RLSB, "PCMA" },
	{ &pcm_size, 2 | FCEUSTATE_RLSB, "PCMS" },
	{ &pcm_latch, 2 | FCEUSTATE_RLSB, "PCML" },
	{ &pcm_clock, 2 | FCEUSTATE_RLSB, "PCMC" },
	{ &reg4242, 1, "4242" },
	{ &dipswitch, 1, "DIPS" },
	{ 0 }
};

static uint8_t *WRAM;

static void PSync(int AND, int OR) {
	uint8_t bankmode = cpu410x[0xb] & 7;
	uint8_t mask = (bankmode == 0x7) ? (0xff) : (0x3f >> bankmode);
	uint32_t block = ((cpu410x[0x0] & 0xf0) << 4) + (cpu410x[0xa] & (~mask));
	uint32_t pswap = (mmc3cmd & 0x40) << 8;

	uint8_t bank0 = cpu410x[0x7];
	uint8_t bank1 = cpu410x[0x8];
	uint8_t bank2 = (cpu410x[0xb] & 0x40) ? (cpu410x[0x9]) : (~1);
	uint8_t bank3 = ~0;
	
	setprg8(0x8000 ^ pswap,(block | (bank0 & mask)) &AND | OR);
	setprg8(0xa000,        (block | (bank1 & mask)) &AND | OR);
	setprg8(0xc000 ^ pswap,(block | (bank2 & mask)) &AND | OR);
	setprg8(0xe000,        (block | (bank3 & mask)) &AND | OR);
}

static void CSync(int AND, int OR) {
	static const uint8_t midx[8] = { 0, 1, 2, 0, 3, 4, 5, 0 };
	uint8_t mask = 0xff >> midx[ppu201x[0xa] & 7];
	uint32_t block = ((cpu410x[0x0] & 0x0f) << 11) + ((ppu201x[0x8] & 0x70) << 4) + (ppu201x[0xa] & (~mask));
	uint32_t cswap = (mmc3cmd & 0x80) << 5;

	uint8_t bank0 = ppu201x[0x6] & (~1);
	uint8_t bank1 = ppu201x[0x6] | 1;
	uint8_t bank2 = ppu201x[0x7] & (~1);
	uint8_t bank3 = ppu201x[0x7] | 1;
	uint8_t bank4 = ppu201x[0x2];
	uint8_t bank5 = ppu201x[0x3];
	uint8_t bank6 = ppu201x[0x4];
	uint8_t bank7 = ppu201x[0x5];

	setchr1(0x0000 ^ cswap,(block | (bank0 & mask)) &AND | OR);
	setchr1(0x0400 ^ cswap,(block | (bank1 & mask)) &AND | OR);
	setchr1(0x0800 ^ cswap,(block | (bank2 & mask)) &AND | OR);
	setchr1(0x0c00 ^ cswap,(block | (bank3 & mask)) &AND | OR);
	setchr1(0x1000 ^ cswap,(block | (bank4 & mask)) &AND | OR);
	setchr1(0x1400 ^ cswap,(block | (bank5 & mask)) &AND | OR);
	setchr1(0x1800 ^ cswap,(block | (bank6 & mask)) &AND | OR);
	setchr1(0x1c00 ^ cswap,(block | (bank7 & mask)) &AND | OR);

	setmirror((mirror ^ 1) & 1);
}

static void SyncEncryption (void) {
	encryptOpcodes = 0;
	if (submapper == 10 && cpu410x[0x1C] &0x02) encryptOpcodes =10;
	if (submapper == 11) {
		encryptOpcodes = 11;
		encryptOpcodesConfig = cpu410x[0x1C];
	}
	if (submapper == 12 && cpu410x[0x1C] &0x40) encryptOpcodes =12;
	if (submapper == 14 && cpu410x[0x1C] &0x40) encryptOpcodes =14;
}

static void Sync256(void) {
	PSync(0x0FFF, 0x000);
	CSync(0x7FFF, 0x000);
	SyncEncryption();
}

static const uint8_t cpuMangles[16][4] = {
	{ 0, 1, 2, 3 }, 	/* Submapper 0: Normal                                  */
	{ 0, 1, 2, 3 }, 	/* Submapper 1: Waixing VT03                            */
	{ 1, 0, 2, 3 }, 	/* Submapper 2: Trump Grand                             */
	{ 0, 1, 2, 3 }, 	/* Submapper 3: Zechess                                 */
	{ 0, 1, 2, 3 }, 	/* Submapper 4: Qishenglong                             */
	{ 0, 1, 2, 3 }, 	/* Submapper 5: Waixing VT02                            */
	{ 0, 1, 2, 3 }, 	/* Submapper 6: unused so far                           */
	{ 0, 1, 2, 3 }, 	/* Submapper 7: unused so far                           */
	{ 0, 1, 2, 3 }, 	/* Submapper 8: unused so far                           */
	{ 0, 1, 2, 3 }, 	/* Submapper 9: unused so far                           */
	{ 0, 1, 2, 3 }, 	/* Submapper A: CPU opcode encryption                   */
	{ 0, 1, 2, 3 }, 	/* Submapper B: CPU opcode encryption                   */
	{ 0, 1, 2, 3 }, 	/* Submapper C: Cheertone (CPU opcode encryption only)  */
	{ 0, 1, 2, 3 }, 	/* Submapper D: Cube Tech (CPU opcode encryption only)  */
	{ 0, 1, 2, 3 }, 	/* Submapper E: Karaoto (CPU opcode encryption only)    */
	{ 0, 1, 2, 3 }  	/* Submapper F: Jungletac (CPU opcode encryption only)  */
};
static DECLFW(UNLOneBusWriteCPU410X) {
/*	FCEU_printf("CPU %04x:%04x\n",A,V); */
	A &=0x3F;
	switch (A) {
	case 0x1: IRQLatch = V & 0xfe; break;	/* �� �� �������� */
	case 0x2: IRQReload = 1; break;
	case 0x3: X6502_IRQEnd(FCEU_IQEXT); IRQa = 0; break;
	case 0x4: IRQa = 1; break;
	default:
		if (A >=0x7 && A <=0xA) A =0x7 +cpuMangle[A -0x7];
		cpu410x[A] = V;
		Sync();
	}
}

static DECLFW(UNLOneBusWriteCPU4242) {
	reg4242 =V;
	Sync();
}

static const uint8_t ppuMangles[16][6] = {
	{ 0, 1, 2, 3, 4, 5 }, 	/* Submapper 0: Normal                                  */
	{ 1, 0, 5, 4, 3, 2 }, 	/* Submapper 1: Waixing VT03                            */
	{ 0, 1, 2, 3, 4, 5 }, 	/* Submapper 2: Trump Grand                             */
	{ 5, 4, 3, 2, 0, 1 }, 	/* Submapper 3: Zechess                                 */
	{ 2, 5, 0, 4, 3, 1 }, 	/* Submapper 4: Qishenglong                             */
	{ 1, 0, 5, 4, 3, 2 }, 	/* Submapper 5: Waixing VT02                            */
	{ 0, 1, 2, 3, 4, 5 }, 	/* Submapper 6: unused so far                           */
	{ 0, 1, 2, 3, 4, 5 }, 	/* Submapper 7: unused so far                           */
	{ 0, 1, 2, 3, 4, 5 }, 	/* Submapper 8: unused so far                           */
	{ 0, 1, 2, 3, 4, 5 }, 	/* Submapper 9: unused so far                           */
	{ 0, 1, 2, 3, 4, 5 }, 	/* Submapper A: CPU opcode encryption                   */
	{ 0, 1, 2, 3, 4, 5 }, 	/* Submapper B: CPU opcode encryption                   */
	{ 0, 1, 2, 3, 4, 5 }, 	/* Submapper C: Cheertone (CPU opcode encryption only)  */
	{ 0, 1, 2, 3, 4, 5 }, 	/* Submapper D: Cube Tech (CPU opcode encryption only)  */
	{ 0, 1, 2, 3, 4, 5 }, 	/* Submapper E: Karaoto (CPU opcode encryption only)    */
	{ 0, 1, 2, 3, 4, 5 }  	/* Submapper F: Jungletac (CPU opcode encryption only)  */
};
static DECLFW(UNLOneBusWritePPU201X) {
/*	FCEU_printf("PPU %04x:%04x\n",A,V); */
	A &=0x0F;
	if (A >=2 && A <=7) A =2 +ppuMangle[A -2];
	ppu201x[A] = V;
	Sync();
}

static const uint8_t mmc3Mangles[16][8] = {
	{ 0, 1, 2, 3, 4, 5, 6, 7 }, 	/* Submapper 0: Normal                                 */
	{ 5, 4, 3, 2, 1, 0, 6, 7 }, 	/* Submapper 1: Waixing VT03                           */
	{ 0, 1, 2, 3, 4, 5, 7, 6 }, 	/* Submapper 2: Trump Grand                            */
	{ 0, 1, 2, 3, 4, 5, 6, 7 }, 	/* Submapper 3: Zechess                                */
	{ 0, 1, 2, 3, 4, 5, 6, 7 }, 	/* Submapper 4: Qishenglong                            */
	{ 0, 1, 2, 3, 4, 5, 6, 7 }, 	/* Submapper 5: Waixing VT02                           */
	{ 0, 1, 2, 3, 4, 5, 6, 7 }, 	/* Submapper 6: unused so far                          */
	{ 0, 1, 2, 3, 4, 5, 6, 7 }, 	/* Submapper 7: unused so far                          */
	{ 0, 1, 2, 3, 4, 5, 6, 7 }, 	/* Submapper 8: unused so far                          */
	{ 0, 1, 2, 3, 4, 5, 6, 7 }, 	/* Submapper 9: unused so far                          */
	{ 0, 1, 2, 3, 4, 5, 6, 7 }, 	/* Submapper A: CPU opcode encryption                  */
	{ 0, 1, 2, 3, 4, 5, 6, 7 }, 	/* Submapper B: CPU opcode encryption                  */
	{ 0, 1, 2, 3, 4, 5, 6, 7 }, 	/* Submapper C: Cheertone (CPU opcode encryption only) */
	{ 0, 1, 2, 3, 4, 5, 6, 7 }, 	/* Submapper D: Cube Tech (CPU opcode encryption only) */
	{ 0, 1, 2, 3, 4, 5, 6, 7 }, 	/* Submapper E: Karaoto (CPU opcode encryption only)   */
	{ 0, 1, 2, 3, 4, 5, 6, 7 }  	/* Submapper F: Jungletac (CPU opcode encryption only) */
};

static DECLFW(UNLOneBusWriteMMC3) {
/*	FCEU_printf("MMC %04x:%04x\n",A,V); */
	if (~cpu410x[0x0B] &0x08) /* FWEN bit must be 0 */
	switch (A & 0xe001) {
	case 0x8000: 
		V =V &0xF8 | mmc3Mangle[V &0x07];
		mmc3cmd = (mmc3cmd & 0x38) | (V & 0xc7);
		Sync();
		break;
	case 0x8001:
	{
		switch (mmc3cmd & 7) {
		case 0: ppu201x[0x6] = V; Sync(); break;
		case 1: ppu201x[0x7] = V; Sync(); break;
		case 2: ppu201x[0x2] = V; Sync(); break;
		case 3: ppu201x[0x3] = V; Sync(); break;
		case 4: ppu201x[0x4] = V; Sync(); break;
		case 5: ppu201x[0x5] = V; Sync(); break;
		case 6: cpu410x[0x7] = V; Sync(); break;
		case 7: cpu410x[0x8] = V; Sync(); break;
		}
		break;
	}
	case 0xa000: mirror = V; Sync(); break;
	case 0xc000: IRQLatch = V; break;
	case 0xc001: IRQReload = 1; break;
	case 0xe000: X6502_IRQEnd(FCEU_IQEXT); IRQa = 0; break;
	case 0xe001: IRQa = 1; break;
	}
}

static void UNLOneBusIRQHook(void) {
	uint32_t count = IRQCount;
	if (!count || IRQReload) {
		IRQCount = IRQLatch;
		IRQReload = 0;
	} else
		IRQCount--;
	if (count && !IRQCount) {
		if (IRQa)
			X6502_IRQBegin(FCEU_IQEXT);
	}
}

static DECLFW(UNLOneBusWriteAPU40XX) {
/*	if(((A & 0x3f)!=0x16) && ((apu40xx[0x30] & 0x10) || ((A & 0x3f)>0x17)))FCEU_printf("APU %04x:%04x\n",A,V); */
	apu40xx[A & 0x3f] = V;
	switch (A & 0x3f) {
	case 0x12:
		if (apu40xx[0x30] & 0x10) {
			pcm_addr = V << 6;
		}
		break;
	case 0x13:
		if (apu40xx[0x30] & 0x10) {
			pcm_size = (V << 4) + 1;
		}
		break;
	case 0x14: /* OneBus DMA: extra 4 bits for address, can write to 2007 instead of 2004 */
		{
			uint32_t t = V <<8 | apu40xx[0x34] &0xF0;
			int shift = apu40xx[0x34] >>1 &7;
			int x;
			if (shift == 0) shift = 8;			
			for (x = 0; x < (1 <<shift); x++) X6502_DMW(apu40xx[0x34] &1? 0x2007: 0x2004, X6502_DMR(t + x));
		}
		return;
	case 0x15:
		if (apu40xx[0x30] & 0x10) {
			pcm_enable = V & 0x10;
			if (pcm_irq) {
				X6502_IRQEnd(FCEU_IQEXT);
				pcm_irq = 0;
			}
			if (pcm_enable)
				pcm_latch = pcm_clock;
			V &= 0xef;
		}
		break;
	}
	defapuwrite[A & 0x3f](A, V);
}

static DECLFR(UNLOneBusReadAPU40XX) {
	uint8_t result = defapuread[A & 0x3f](A);
/*	FCEU_printf("read %04x, %02x\n",A,result); */
	switch (A & 0x3f) {
	case 0x15:
		if (apu40xx[0x30] & 0x10) {
			result = (result & 0x7f) | pcm_irq;
		}
		break;
	case 0x17:
		if (cpu410x[0x0B] == 0x14) result = result &~0x04 | (dipswitch &1? 0x04: 0x00); /* Super Joy III pad */
	}
	return result;
}

static DECLFR(readDIP_FamilyPocket) {
	return dipswitch &1? 8: 0;
}

static void UNLOneBusCpuHook(int a) {
	if (pcm_enable) {
		pcm_latch -= a;
		if (pcm_latch <= 0) {
			pcm_latch += pcm_clock;
			pcm_size--;
			if (pcm_size < 0) {
				pcm_irq = 0x80;
				pcm_enable = 0;
				X6502_IRQBegin(FCEU_IQEXT);
			} else {
				uint16_t addr = pcm_addr | ((apu40xx[0x30]^3) << 14);
				uint8_t raw_pcm = ARead[addr](addr) >> 1;
				defapuwrite[0x11](0x4011, raw_pcm);
				pcm_addr++;
				pcm_addr &= 0x7FFF;
			}
		}
	}
}

static void UNLOneBusPower(void) {
	uint32_t i;
	IRQReload = IRQCount = IRQa = 0;

	memset(cpu410x, 0x00, sizeof(cpu410x));
	memset(ppu201x, 0x00, sizeof(ppu201x));
	memset(apu40xx, 0x00, sizeof(apu40xx));
	cpu410x[0x0F] = 0xFF;
	if (submapper == 10 || submapper == 11) cpu410x[0x1C] = 0x02;
	if (submapper == 12 || submapper == 14) cpu410x[0x1C] = 0x40;

	/* Preserve separate CHR ROM in extracted OneBus games. */
	if (!VROM_size)
		SetupCartCHRMapping(0, PRGptr[0], PRGsize[0], 0);

	for (i = 0; i < 64; i++) {
		defapuread[i] = GetReadHandler(0x4000 | i);
		defapuwrite[i] = GetWriteHandler(0x4000 | i);
	}
	SetReadHandler(0x4000, 0x403f, UNLOneBusReadAPU40XX);
	SetWriteHandler(0x4000, 0x403f, UNLOneBusWriteAPU40XX);

	SetReadHandler(0x412C, 0x412C, readDIP_FamilyPocket);
	SetReadHandler(0x6000, 0xFFFF, CartBR);
	SetWriteHandler(0x6000, 0x7FFF, CartBW);
	SetWriteHandler(0x2010, 0x201f, UNLOneBusWritePPU201X);
	SetWriteHandler(0x4100, 0x413f, UNLOneBusWriteCPU410X);
	SetWriteHandler(0x4242, 0x4242, UNLOneBusWriteCPU4242);
	SetWriteHandler(0x8000, 0xffff, UNLOneBusWriteMMC3);

	FCEU_CheatAddRAM(8, 0x6000, WRAM);
	setprg8r(0x10, 0x6000, 0);
	dipswitch =0;
	Sync();
}

static void UNLOneBusReset(void) {
	IRQReload = IRQCount = IRQa = 0;

	memset(cpu410x, 0x00, sizeof(cpu410x));
	memset(ppu201x, 0x00, sizeof(ppu201x));
	memset(apu40xx, 0x00, sizeof(apu40xx));
	cpu410x[0x0F] = 0xFF;
	if (submapper == 10 || submapper == 11) cpu410x[0x1C] = 0x02;
	if (submapper == 12 || submapper == 14) cpu410x[0x1C] = 0x40;
	reg4242 =0;
	dipswitch++;

	Sync();
}

static void StateRestore(int version) {
	Sync();
}

static void UNLOneBus_Close(void) {
	if (WRAM)
		FCEU_gfree(WRAM);
	WRAM = NULL;
	/* Mapper270_Init / Mapper436_Init allocate an additional CHRRAM after
	 * UNLOneBus_Init returns; free that here too to avoid leaking it on
	 * every load/unload cycle. */
	if (CHRRAM)
		FCEU_gfree(CHRRAM);
	CHRRAM = NULL;
}

void UNLOneBus_Init(CartInfo *info) {
	info->Power = UNLOneBusPower;
	info->Reset = UNLOneBusReset;
	info->Close = UNLOneBus_Close;
	Sync = Sync256;

	if (info->iNES2)
		submapper =info->submapper;
	else {
		/* Compare the first four MD5 bytes literally to avoid the previous
		 * endian-dependent (uint32_t) reinterpretation, which silently
		 * mismatched on big-endian hosts and disabled the PowerJoy Supermax
		 * variant detection. */
		const uint8_t *md5 = info->MD5;
		int is_305fcdc3 = (md5[0] == 0xc3 && md5[1] == 0xcd && md5[2] == 0x5f && md5[3] == 0x30);
		int is_6abfce8e = (md5[0] == 0x8e && md5[1] == 0xce && md5[2] == 0xbf && md5[3] == 0x6a);
		submapper = (is_305fcdc3 || is_6abfce8e) ? 2 : 0; /* PowerJoy Supermax Carts */
	}

	cpuMangle =cpuMangles[submapper];
	ppuMangle =ppuMangles[submapper];
	mmc3Mangle =mmc3Mangles[submapper];

	GameHBIRQHook = UNLOneBusIRQHook;
	MapIRQHook = UNLOneBusCpuHook;
	GameStateRestore = StateRestore;
	AddExState(&StateRegs, ~0, 0, 0);
	
	WRAM = (uint8_t*)FCEU_gmalloc(8192);
	SetupCartPRGMapping(0x10, WRAM, 8192, 1);
}

static void Sync270(void) {
	int OR =0;
	switch(submapper) {
		case 1:  OR = cpu410x[0x2C] &0x02? 0x0800: 0x0000;
		         break;
		case 2:  OR =(cpu410x[0x2C] &0x02? 0x0800: 0x0000) |
		             (cpu410x[0x2C] &0x01? 0x1000: 0x0000);
			 break;
		case 3:  OR = cpu410x[0x2C] &0x04? 0x0800: 0x0000;
		         break;
		default: OR =(cpu410x[0x2C] &0x06? 0x0800: 0x0000) |
		             (cpu410x[0x2C] &0x01? 0x1000: 0x0000);
			 break;
	}
	PSync(0x07FF, OR);
	if (reg4242 &1) {
		setchr8r(0x10, 0);
		setmirror((mirror ^ 1) & 1);
	} else
		CSync(0x3FFF, OR <<3);
	SyncEncryption();
}

void Mapper270_Init(CartInfo *info) {
	UNLOneBus_Init(info);
	cpuMangle = cpuMangles[0];
	ppuMangle = ppuMangles[0];
	mmc3Mangle = mmc3Mangles[0];
	
	CHRRAMSIZE = 8192;
	CHRRAM = (uint8_t*)FCEU_gmalloc(CHRRAMSIZE);
	SetupCartCHRMapping(0x10, CHRRAM, CHRRAMSIZE, 1);
	AddExState(CHRRAM, CHRRAMSIZE, 0, "CHRR");
	
	Sync = Sync270;
}

static uint8_t MMC1_shift, MMC1_bits, MMC1_reg[4];
static uint8_t* securityROM_data;
static uint8_t securityROM_output;
static uint16_t securityROM_state;
static uint8_t securityROM_command;
static uint16_t securityROM_bitPosition;
static SFORMAT StateRegs_408[] = {
	{ &MMC1_shift, 1, "MM1S" },
	{ &MMC1_bits, 1, "MM1B" },
	{ MMC1_reg, 4, "MM1R" },
	{ &securityROM_state, 2 | FCEUSTATE_RLSB, "SRST" },
	{ &securityROM_bitPosition, 2 | FCEUSTATE_RLSB, "SRBP" },
	{ &securityROM_command, 1, "SRCM" },
	{ &securityROM_output, 1, "SROU" },
	{ 0 }
};

static void PSyncMMC1(int AND, int OR) {
	uint8_t bankmode = cpu410x[0xB] &7;
	uint8_t mask = bankmode == 0x7? 0xFF: (0x3F >>bankmode);
	uint32_t block = cpu410x[0x0] <<4 &0xF00 | cpu410x[0xA] &~mask;
	mask >>= 1;
	block >>= 1;
	AND >>= 1;
	OR >>= 1;
	if (MMC1_reg[0] &0x08) {
		if (MMC1_reg[0] &0x04) {
			setprg16(0x8000, (block | MMC1_reg[3] &mask) &AND | OR);
			setprg16(0xC000, (block | 0xFF        &mask) &AND | OR);
		} else {
			setprg16(0x8000, (block | 0x0         &mask) &AND | OR);
			setprg16(0xC000, (block | MMC1_reg[3] &mask) &AND | OR);
		}
	} else
		setprg32(0x8000, ((block | MMC1_reg[3] &mask) &AND | OR) >>1);
}

static void Sync408(void) {
	int bankSelect = 0;
	if (securityROM_data)
		bankSelect = cpu410x[0x0F] >>5;
	else
	if (submapper == 12 || submapper == 14)
		bankSelect = (cpu410x[0x39] &0x08? 1: 0) | (cpu410x[0x39] &0x04? 2: 0);
	else
		bankSelect = cpu410x[0x39] &0x02? 1: 0;
	
	if (cpu410x[0x0B] &0x20 && ~cpu410x[0x0B] &0x10)
		PSyncMMC1(0x07FF, bankSelect <<11);
	else
		PSync(0x07FF, bankSelect <<11);
	
	if (cpu410x[0x00] &0x08) {
		setchr8r(0x10, 0);
		setmirror((mirror ^ 1) & 1);
	} else
		CSync(0x3FFF, bankSelect <<14);
	SyncEncryption();
}

static DECLFW(UNLOneBusWriteUNROM) {
	cpu410x[0x7] = V <<1 | 0;
	cpu410x[0x8] = V <<1 | 1;
	Sync();
}

static DECLFW(UNLOneBusWriteMMC1) {
	if (V &0x80) {
		MMC1_reg[0] |= 0x0C;
		MMC1_shift = 0;
		MMC1_bits = 0;
	} else {
		MMC1_shift |= (V &1) << MMC1_bits++;
		if (MMC1_bits == 5) {
			MMC1_reg[A >>13 &3] = MMC1_shift;
			MMC1_shift = 0;
			MMC1_bits =0 ;
		}
	}
	if (MMC1_reg[0] &0x10) {
		ppu201x[0x6] = MMC1_reg[1] <<2 |0;
		ppu201x[0x7] = MMC1_reg[1] <<2 |2;
		ppu201x[0x2] = MMC1_reg[2] <<2 |0;
		ppu201x[0x3] = MMC1_reg[2] <<2 |1;
		ppu201x[0x4] = MMC1_reg[2] <<2 |2;
		ppu201x[0x5] = MMC1_reg[2] <<2 |3;
	} else {
		ppu201x[0x6] = MMC1_reg[1] <<2 &~7 |0;
		ppu201x[0x7] = MMC1_reg[1] <<2 &~7 |2;
		ppu201x[0x2] = MMC1_reg[1] <<2 &~7 |4;
		ppu201x[0x3] = MMC1_reg[1] <<2 &~7 |5;
		ppu201x[0x4] = MMC1_reg[1] <<2 &~7 |6;
		ppu201x[0x5] = MMC1_reg[1] <<2 &~7 |7;
	}
	Sync();
}

static DECLFW (Mapper408_WriteEmulatedASIC) {
	if (cpu410x[0x0B] &0x20) {
		if (cpu410x[0x0B] &0x10)
			UNLOneBusWriteUNROM(A, V);
		else
			UNLOneBusWriteMMC1(A, V);
	} else
		UNLOneBusWriteMMC3(A, V);
}

static DECLFR (Mapper408_ReadSecurityROM) {
	if (cpu410x[0x38] &0x08)
		return cpu410x[0x39] &~0x01;
	else
		return cpu410x[0x39] &~0x09 | (securityROM_output? 0x08: 0x00);
}

static DECLFW (Mapper408_WriteSecurityROM) {
	if (~V &0x04) { /* Chip Select */
		if (~cpu410x[0x39] &0x02 & V &0x02) { /* Rising clock edge */
			if (securityROM_state < 8) {
				securityROM_command = securityROM_command <<1 | (V &0x08? 1: 0);
				if (++securityROM_state == 8 && securityROM_command != 0x20)
					securityROM_state = 0;
				else
					securityROM_bitPosition = 0;
			} else {
				securityROM_output = securityROM_data[securityROM_bitPosition >>3 &0xFF] >> (7 - (securityROM_bitPosition &7)) &1;
				if (++securityROM_bitPosition >= 2048) securityROM_state = 0;
			}
		}
	} else {
		securityROM_state = 0;
		securityROM_command = 0;
		securityROM_bitPosition = 0;
	}
	cpu410x[0x39] = V;
}

static void Mapper408_Power (void) {
	UNLOneBusPower();
	SetWriteHandler(0x8000, 0XFFFF, Mapper408_WriteEmulatedASIC);
	if (securityROM_data) {
		SetReadHandler(0x4139, 0x4139, Mapper408_ReadSecurityROM);
		SetWriteHandler(0x4139, 0x4139, Mapper408_WriteSecurityROM);
		securityROM_state = 0;
		securityROM_command = 0;
		securityROM_bitPosition = 0;
	}
	MMC1_shift = 0;
	MMC1_bits = 0;
	MMC1_reg[0] = 0x0C;
}

void Mapper408_Init(CartInfo *info) {
	UNLOneBus_Init(info);
	info->Power = Mapper408_Power;
	cpuMangle = cpuMangles[0];
	ppuMangle = ppuMangles[0];
	mmc3Mangle = mmc3Mangles[0];
	securityROM_data = MiscROM && info->miscROMSize >= 256? MiscROM: NULL;
	
	CHRRAMSIZE = 8192;
	CHRRAM = (uint8_t*)FCEU_gmalloc(CHRRAMSIZE);
	SetupCartCHRMapping(0x10, CHRRAM, CHRRAMSIZE, 1);
	AddExState(CHRRAM, CHRRAMSIZE, 0, "CHRR");
	AddExState(&StateRegs_408, ~0, 0, 0);
	
	Sync = Sync408;
}

static void Sync436(void) {
	int OR =0;
	switch(submapper) {
		case 1:  OR = cpu410x[0x1C] &0x01 && ~cpu410x[0x1C] &0x04? 0x0800: 0x0000;
	                 PSync(0xF7FF, OR);
                         CSync(0xBFFF, OR <<3);
		         break;
		default: PSync(0xF3FF, (cpu410x[0x0F] &0x20? 0x0400: 0x0000) | (cpu410x[0x00] &0x40? 0x0800: 0x0000));
                         CSync(0x9FFF, (cpu410x[0x0F] &0x20? 0x2000: 0x0000) | (cpu410x[0x00] &0x04? 0x4000: 0x0000));
			 break;
	}
	SyncEncryption();
}

void Mapper436_Init(CartInfo *info) {
	UNLOneBus_Init(info);
	cpuMangle = cpuMangles[0];
	ppuMangle = ppuMangles[0];
	mmc3Mangle = mmc3Mangles[0];
	
	CHRRAMSIZE = 8192;
	CHRRAM = (uint8_t*)FCEU_gmalloc(CHRRAMSIZE);
	SetupCartCHRMapping(0x10, CHRRAM, CHRRAMSIZE, 1);
	AddExState(CHRRAM, CHRRAMSIZE, 0, "CHRR");
	
	Sync = Sync436;
}
